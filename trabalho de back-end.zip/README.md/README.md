# Sistema de Gerenciamento de Pessoas - Universidade

Este projeto implementa uma API para o gerenciamento de pessoas de uma universidade. Ele permite criar e consultar pessoas usando um banco de dados MySQL.

## Tecnologias Utilizadas
- Java
- Spring Boot
- Spring Data JPA
- MySQL
- Lombok

## Como rodar o projeto
1. Clonar o repositório.
2. Configurar o MySQL no arquivo `application.properties`.
3. Executar o projeto através de uma IDE ou linha de comando.

## Endpoints
- `POST /api/pessoas` - Cria uma nova pessoa.
- `GET /api/pessoas/{id}` - Retorna a pessoa com o ID especificado.

## Integrantes
- Nome do integrante 1
- Nome do integrante 2
