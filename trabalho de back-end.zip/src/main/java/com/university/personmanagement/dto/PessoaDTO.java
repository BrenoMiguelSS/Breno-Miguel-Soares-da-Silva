package com.university.personmanagement.dto;

import lombok.Data;

@Data
public class PessoaDTO {

    private String nome;
    private String cpf;
    private Integer idade;
}